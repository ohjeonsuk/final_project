import streamlit as st

def main():
    st.title('Diagram')
    # 이미지 표시 (이미지 크기 조절)
    st.image("diagram.png")

if __name__ == "__main__":
    main()

