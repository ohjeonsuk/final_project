import streamlit as st


def main():
    #템플릿의 HTML 코드
    template_html = """
    <!-- 부트스트랩 CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    """

    # 추가된 코드: 새로운 스타일 시트 불러오기
    st.markdown(
        """
        <style>
        .custom-jumbotron {
            padding: 40px;
            background-color: #f2f2f2 !important;  /* 연한 회색 배경색 */
        }

        .bold-text {
            font-weight: bold;
        }

        /* 추가된 스타일: 텍스트 가운데 정렬 */
        .text-center {
            text-align: center;
        }

        /* 추가된 스타일: 소제목의 글자 크기 조절 */
        .subtitle {
            font-size: 18px;
        }
        </style>
        """,
        unsafe_allow_html=True
    )

    # Jumbotron 부분
    st.markdown(
        """
        <div class="jumbotron custom-jumbotron text-center">
            <h1 class="display-4 bold-text">데이터 수집 방법 및 전처리 과정</h1>
            <hr class="my-4">
        </div>
        """,
        unsafe_allow_html=True
    )
