
import streamlit as st
from streamlit_chat import message
import hashlib
import hmac
import base64
import time
import requests
import json

class ChatbotMessageSender:
    ep_path = 'https://n5n6w6fc1c.apigw.ntruss.com/team3_introduction/beta/'
    secret_key = 'VVVXZlRCY3VtdFBpTlNqenJVSHFRSVRCenl1SXFidEM='

    def req_message_send(self, user_input='안녕'):
        timestamp = self.get_timestamp()
        request_body = {
            'version': 'v2',
            'userId': 'instructor3',
            'timestamp': timestamp,
            'bubbles': [
                {
                    'type': 'text',
                    'data': {
                        'description': user_input
                    }
                }
            ],
            'event': 'send'
        }

        encode_request_body = json.dumps(request_body).encode('UTF-8')
        signature = self.make_signature(self.secret_key, encode_request_body)
        custom_headers = {
            'Content-Type': 'application/json;UTF-8',
            'X-NCP-CHATBOT_SIGNATURE': signature
        }

        response = requests.post(headers=custom_headers, url=self.ep_path, data=encode_request_body)

        return response

    @staticmethod
    def get_timestamp():
        timestamp = int(time.time() * 1000)
        return timestamp

    @staticmethod
    def make_signature(secret_key, request_body):
        secret_key_bytes = bytes(secret_key, 'UTF-8')
        signing_key = base64.b64encode(hmac.new(secret_key_bytes, request_body, digestmod=hashlib.sha256).digest())
        return signing_key


def main():
    if 'past' not in st.session_state:
        st.session_state['past'] = []
    if 'generated' not in st.session_state:
        st.session_state['generated'] = []

    st.title("채팅을 시작해 보세요!")

    # 메세지 입력창을 채팅 기록 아래에 배치
    input_text = st.text_input("안녕을 입력하세요:")

    if st.button("전송"):
        if input_text:
            handle_user_input(input_text)

    display_chat_history()


def handle_user_input(user_input):
    res_obj = ChatbotMessageSender()
    res = res_obj.req_message_send(user_input)

    if res.status_code == 200:
        dict_res = res.json()
        chatbot_output = dict_res['bubbles'][0]['data']['description']

        st.session_state.past.append(user_input)
        st.session_state.generated.append(chatbot_output)


def display_chat_history():
    with st.expander("채팅 기록", expanded=True):
        for i in range(len(st.session_state['past'])):
            message(st.session_state['past'][i], is_user=True, key=str(i) + '_user')
            if len(st.session_state['generated']) > i:
                message(st.session_state['generated'][i], key=str(i) + '_bot')


if __name__ == "__main__":
    if 'past' not in st.session_state:
        st.session_state['past'] = []
    if 'generated' not in st.session_state:
        st.session_state['generated'] = []

    main()
