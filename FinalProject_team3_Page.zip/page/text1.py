import streamlit as st
from PIL import Image

def main():
	img = Image.open('page/homepage.jpg')
	st.image(img)

if __name__ == "__main__":
    main()
