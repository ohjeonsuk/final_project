import streamlit as st
from utils import koalpaca_stirpt as ks

def main():
    st.title('Koalpaca')
    
    st.header('Colap 실행 파일')
    
    # 코랩 아이콘과 링크 스타일
    colab_link = "https://drive.google.com/file/d/167ZgbpPaDBqrzBlTVZ-DGsC_F_UDEGpe/view?usp=sharing"
    st.markdown(f"<a href='{colab_link}' target='_blank' rel='noopener noreferrer' style='font-size:20px; color: #1f4681; text-decoration: none; display: flex; align-items: center;'>"
                f"<img src='https://colab.research.google.com/assets/colab-badge.svg' alt='Open in Colab' style='margin-right: 8px;'> Koalpaca fintuning을 통한 모델 학습"
                f"</a>", unsafe_allow_html=True)
    
    st.markdown("<hr/>", unsafe_allow_html=True)
    
    st.header('데이터셋 제작 방법')
    ks.main()
    ks.main1()
    ks.main2()
    st.markdown("<hr/>", unsafe_allow_html=True)
    
    st.header('Fine tune 방식 학습 방법')
    ks.main3()
    ks.main4()
    st.markdown("<hr/>", unsafe_allow_html=True)

if __name__ == "__main__":
    main()


