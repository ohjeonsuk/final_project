# first_page.py 파일
import streamlit as st
from streamlit_chat import message

def main():
    #템플릿의 HTML 코드
    template_html = """
    <!-- 부트스트랩 CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    """

    # 추가된 코드: 새로운 스타일 시트 불러오기
    st.markdown(
        """
        <style>
        .custom-jumbotron {
            padding: 40px;
            background-color: #f2f2f2 !important;  /* 연한 회색 배경색 */
        }

        .bold-text {
            font-weight: bold;
        }

        /* 추가된 스타일: 텍스트 가운데 정렬 */
        .text-center {
            text-align: center;
        }

        /* 추가된 스타일: 소제목의 글자 크기 조절 */
        .subtitle {
            font-size: 18px;
        }
        </style>
        """,
        unsafe_allow_html=True
    )

    # Jumbotron 부분
    st.markdown(
        """
        <div class="jumbotron custom-jumbotron text-center">
            <h1 class="display-4 bold-text">자연어처리 기반 가짜뉴스 판별 시스템</h1>
            <p class="lead subtitle bold-text">멀티캠퍼스 데이터 시각화&분석 취업캠프(Python)</p>
            <hr class="my-4">
            <p class="lead bold-text">권지현, 서정무, 이승우, 오전석, 임성균, 최서진</p>
        </div>
        """,
        unsafe_allow_html=True
    )
