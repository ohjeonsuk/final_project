import streamlit as st
from utils import fact_module as fm

def main():
    st.title("SNU 팩트체크 크롤링")

    # 사용자로부터 버튼 선택 및 크롤링할 페이지 범위 입력 받기
    status_class = st.radio("Choose a status:", ['전혀 사실 아님', '대체로 사실 아님', '절반의 사실', '대체로 사실', '사실'])
    start_page = st.number_input("크롤링할 시작 페이지를 입력하세요:", min_value=1, step=1)
    end_page = st.number_input("크롤링할 종료 페이지를 입력하세요:", min_value=start_page, step=1)

    if st.button("Scrape Data"):
        st.text("검색 및 크롤링 중입니다. 잠시 기다려주세요...")
        df = fm.scrape_page(start_page, end_page, status_class)
        st.dataframe(df)
        st.text("크롤링이 완료되었습니다!")

if __name__ == "__main__":
    main()

