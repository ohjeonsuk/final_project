import streamlit as st
from streamlit_option_menu import option_menu
from page import first_page
from page import intro
from page import second_page
from page import you_script
from page import naver_news
from page import fact
from page import koalpaca
from page import bert
from utils import fact_module
from page import dia
from page import conclu

# 한 페이지당 한 번만 호출되어야 함
st.set_page_config(
    page_title="Navbar, Jumbotron, and Carousel Template",
    page_icon=":bar_chart:",
    layout="wide"
)

with st.sidebar:
    choose = option_menu("Final Project", ["Home", "Diagram", "Source","BERT", "Koalpaca", "Evaluation"],
                         icons=['bi bi-house-door-fill','bi bi-diagram-2-fill', 'bi bi-pencil-fill', 'bi bi-clipboard-data', 'bi bi-clipboard-data-fill','bi bi-stack'],
                         menu_icon="bi bi-bookmark-fill", default_index=0,
                         styles={
                             "container": {"padding": "5!important", "background-color": "#fafafa"},
                             "icon": {"color": "black", "font-size": "25px"},
                             "nav-link": {"font-size": "16px", "text-align": "left", "margin":"0px", "color": "black", "--hover-color": "#eee"},
                             "nav-link-selected": {"background-color": "#9fc5e8"},
                             "menu-title": {"color": "black",  "font-weight": "bold"}
                         }  # css 설정
    )

if choose == "Home":
    first_page.main()
    intro.main()

if choose =="Diagram":
    dia.main()

if choose == "Source":
    # 선택박스 스타일링
    st.markdown("""
        <style>
            div[data-baseweb="select"] {
                font-size: 24px;        /* 글자 크기 */
                font-weight: bold;      /* 굵기 */
            }
        </style>
    """, unsafe_allow_html=True)

    # 선택박스 렌더링
    s_box = st.selectbox('탭을 눌러 메뉴를 선택하세요.', ('유튜브 스크립트', '네이버 뉴스 크롤링', 'SNU Factcheck 크롤링'))
    
    if s_box == "유튜브 스크립트":
        you_script.main()
        option = ['Code']
        if st.button(option[0]):
            you_script.main1()
            you_script.main2()
            you_script.main3()
            you_script.main4()
            you_script.main5()
            you_script.main6()

    if s_box == "네이버 뉴스 크롤링":
        naver_news.main()
        option = ['Code']
        if st.button(option[0]):
             naver_news.main1()
             naver_news.main2()
             naver_news.main3()
             naver_news.main4()

    if s_box == "SNU Factcheck 크롤링":
        fact.main()
        option = ['Code']
        if st.button(option[0]):
             fact_module.main1()
             fact_module.main2()
             fact_module.main3()

if choose == "Koalpaca":
    koalpaca.main()

if choose == "BERT":
    bert.main()

if choose == "Evaluation":
    conclu.main()
    conclu.main1()