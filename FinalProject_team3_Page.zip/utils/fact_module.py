import streamlit as st
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup as bs
import pandas as pd
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from utils import naver_code as ns

def get_data_from_page(soup, status_class):
    div_elements = soup.find_all('div', class_='jsx-18931043 fact-check-cards-container')
    data_list = []
    for div_index, div in enumerate(div_elements):
        title_elements = div.find_all('div', class_='fact-check-title')
        for title_index, title_element in enumerate(title_elements):
            title_text = title_element.text.strip()
            data_list.append({
                'Index': f"{div_index + 1}.{title_index + 1}",
                'Title': title_text,
                'Status': status_class
            })
    return data_list

def scrape_page(start_page, end_page, status_class):
    options = Options()
    options.add_experimental_option("detach", True)
    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=options)

    # 사용자가 선택한 버튼에 따라 URL 설정
    base_url = "https://factcheck.snu.ac.kr/"
    if status_class == '전혀 사실 아님':
        url = f"{base_url}?score=1&page={start_page}"
    elif status_class == '대체로 사실 아님':
        url = f"{base_url}?score=2&page={start_page}"
    elif status_class == '절반의 사실':
        url = f"{base_url}?score=3&page={start_page}"
    elif status_class == '대체로 사실':
        url = f"{base_url}?score=4&page={start_page}"
    elif status_class == '사실':
        url = f"{base_url}?score=5&page={start_page}"

    # Selenium을 사용하여 페이지 열기
    driver.get(url)

    # 페이지가 로드될 때까지 대기
    wait = WebDriverWait(driver, 10)
    wait.until(EC.presence_of_element_located((By.CLASS_NAME, 'jsx-18931043')))

    # 데이터를 담을 리스트
    data_list = []

    # 페이지 버튼을 찾아서 클릭하기
    page_number = start_page
    while page_number <= end_page:
        try:
            # 현재 페이지의 HTML을 BeautifulSoup으로 파싱
            soup = bs(driver.page_source, 'html.parser')

            # 현재 페이지에서 데이터 수집
            data_list.extend(get_data_from_page(soup, status_class))

            # Scroll into view to make the next page button clickable
            next_page_button = driver.find_element(By.CLASS_NAME, 'page-index-button-next')
            driver.execute_script("arguments[0].scrollIntoView(true);", next_page_button)

            # Use JavaScript to click the next page button
            driver.execute_script("arguments[0].click();", next_page_button)

            # 페이지가 로드될 때까지 대기
            wait.until(EC.presence_of_element_located((By.CLASS_NAME, 'jsx-18931043')))

            page_number += 1
        except Exception as e:
            print(f"An error occurred: {e}")
            break

    # 브라우저 종료
    driver.quit()

    # 데이터프레임 생성
    df = pd.DataFrame(data_list)
    return df

def main1():
    st.header('1. 필요한 모듈 불러오기')
    zero_code = '''
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup as bs
import pandas as pd
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
'''

    ns.display_code(zero_code)

def main2():
    st.header('2. 특정 클래스의 데이터 리스트에 저장하기')
    first_code = '''
def get_data_from_page(soup, status_class):
    # 'jsx-18931043 fact-check-cards-container' 클래스를 갖는 div 요소를 찾습니다.
    div_elements = soup.find_all('div', class_='jsx-18931043 fact-check-cards-container')
    
    # 추출된 정보를 저장할 리스트를 초기화합니다.
    data_list = []
    
    # 각 div 요소에 대해 반복합니다.
    for div_index, div in enumerate(div_elements):
        # 현재 div 요소에서 'fact-check-title' 클래스를 갖는 div 요소를 찾습니다.
        title_elements = div.find_all('div', class_='fact-check-title')
        
        # 각 title 요소에 대해 반복합니다.
        for title_index, title_element in enumerate(title_elements):
            # 제목을 추출합니다.
            title_text = title_element.text.strip()
            
            # 추출한 정보를 딕셔너리에 저장하고 리스트에 추가합니다.
            data_list.append({
                'Index': f"{div_index + 1}.{title_index + 1}",
                'Title': title_text,
                'Status': status_class
            })
    
    # 최종적으로 모은 데이터 리스트를 반환합니다.
    return data_list

'''

    ns.display_code(first_code)

def main3():
    st.header('Selenium을 사용해 웹스크래핑 후 dataframe으로 반환')
    third_code = '''
def scrape_page(start_page, end_page, status_class):
    # Selenium 설정
    options = Options()
    options.add_experimental_option("detach", True)
    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=options)

    # 사용자가 선택한 버튼에 따라 URL 설정
    base_url = "https://factcheck.snu.ac.kr/"
    if status_class == '전혀 사실 아님':
        url = f"{base_url}?score=1&page={start_page}"
    elif status_class == '대체로 사실 아님':
        url = f"{base_url}?score=2&page={start_page}"
    elif status_class == '절반의 사실':
        url = f"{base_url}?score=3&page={start_page}"
    elif status_class == '대체로 사실':
        url = f"{base_url}?score=4&page={start_page}"
    elif status_class == '사실':
        url = f"{base_url}?score=5&page={start_page}"

    # Selenium을 사용하여 페이지 열기
    driver.get(url)

    # 페이지가 로드될 때까지 대기
    wait = WebDriverWait(driver, 10)
    wait.until(EC.presence_of_element_located((By.CLASS_NAME, 'jsx-18931043')))

    # 데이터를 담을 리스트
    data_list = []

    # 페이지 버튼을 찾아서 클릭하기
    page_number = start_page
    while page_number <= end_page:
        try:
            # 현재 페이지의 HTML을 BeautifulSoup으로 파싱
            soup = bs(driver.page_source, 'html.parser')

            # 현재 페이지에서 데이터 수집
            data_list.extend(get_data_from_page(soup, status_class))

            # Scroll into view to make the next page button clickable
            next_page_button = driver.find_element(By.CLASS_NAME, 'page-index-button-next')
            driver.execute_script("arguments[0].scrollIntoView(true);", next_page_button)

            # Use JavaScript to click the next page button
            driver.execute_script("arguments[0].click();", next_page_button)

            # 페이지가 로드될 때까지 대기
            wait.until(EC.presence_of_element_located((By.CLASS_NAME, 'jsx-18931043')))

            page_number += 1
        except Exception as e:
            print(f"An error occurred: {e}")
            break

    # 브라우저 종료
    driver.quit()

    # 데이터프레임 생성
    df = pd.DataFrame(data_list)
    return df
'''

    ns.display_code(third_code)
