# 필요한 라이브러리를 가져옵니다
import streamlit as st
import pandas as pd
from utils import youtube_code as yc

def main():
    # 칼럼 필드의 데이터
    fields = [
        'sourceDataInfo_newsID',
        'sourceDataInfo_newsCategory',
        'sourceDataInfo_newsSubcategory',
        'sourcebatalnfo_newsTitle',
        'sourceDataInfo_newsSubTitle',
        'sourceDatalnfo_newsContent',
        'sourceDataInfo_partNum',
        'sourceDatalnfo_useType',
        'sourceDataInfo_processType',
        'sourceDataInfo_processPattern',
        'sourceDataInfo_processLevel',
        'sourceDataInfo_sentenceCount',
        'sourceDataInfo_sentenceInfo',
        'labeledDataInfo_newTitle',
        'labeledDataInfo_clickbaitClass',
        'TabeledDataInfo_referSentenceInfo'
    ]

    # 데이터를 세로로 나열한 리스트 생성
    data = {
        'field': fields
    }

    # 데이터프레임 생성
    df = pd.DataFrame(data)

    # 번호와 함께 데이터프레임 표시
    st.subheader('훈련 데이터')
    st.table(df.style.apply(lambda x: ['border: 2px solid red' if x.name == 5 or x.name == 14 else '' for i in x], axis=1).hide_index())

def main1():
    aihub_link = "https://www.aihub.or.kr/aihubdata/data/view.do?currMenu=115&topMenu=100&aihubDataSe=realm&dataSetSn=71338"
    link_text = "● 데이터셋에 대한 더 자세한 정보는"
    additional_text = "하여 확인할 수 있습니다."
    st.markdown(f"{link_text} [AI_Hub으로_이동]({aihub_link}) {additional_text}", unsafe_allow_html=True)
    st.write('● Aihub 낚시성 기사 중 Part2(세부) - Clickbait_Auto(낚시성 기사_자동 생성)의 EU(경제)와 Clickbait_Direct(낚시성기사_직접생성)의 EC(경제), NonClickbait_Auto(非낚시성기사_자동생성)의 EC(경제) 기사 데이터의 일부분 사용')
    st.write('● newsContent를 읽고 clickbaitClass가 0이면 낚시성기사, 1이면 비낚시성기사')

def main2():
     st.subheader('검증 데이터')
     code = '''
{
"sourceDataInfo": {
"newsID": "",
"newsCategory": "엔터",
"newsSubcategory": "주가",
"newsTitle": "블랙핑크 재계약, YG엔터 추가 우려 없어",
"newsSubTitle": "",
"newsContent": "NH투자증권은 18일 와이지엔터테인먼트에 대해 걸그룹 블랙핑크의 재계약으로 가장 큰 불확실성이 해소됐고 추가적인 우려 요인은 없는 상태라고 분석했다.이화정 연구원은 이날 관련 보고서에서 와이지엔터테인먼트의 목표주가(8만7천원)와 투자의견(매수)을 종전대로 지켰다.이 연구원은 블랙핑크 재계약 공시로 가장 큰 불확실성이 해소된 가운데 베이비몬스터 데뷔곡 글로벌 지표도 흥행에 성공해 더 이상 남은 추가 우려 요인이 없다면서 베이비몬스터·트레저의 고성장을 확인하거나 블랙핑크의 컴백 이벤트가 본격적인 주가 상향 계기로 작용하게 될 것이라고 분석했다.블랙핑크의 최근 재계약 방식에 대해선 아티스트 배분율 상승 폭은 제한적이고 계약금 역시 회수 가능한 범위 내에서 결정된 것으로 파악된다고 짚었다.앞으로 멤버들의 개인 활동에 대해서도 쇼 참여나 브랜드 사업 개시 등 개인기가 더 중요한 개인 활동의 경우 자율성이 보장될 것이라면서도 다만 모든 개인 활동은 그룹 활동을 방해하지 않는 범위에서 진행될 것으로 예상했다.베이비몬스터에 대해서도 현재 확인된 팬덤 기반을 고려할 때 흥행을 이어갈 가능성이 커 보인다고 분석했다."
}
}
'''
     yc.display_code(code)
     st.write('● 네이버 뉴스에서 크롤링한 기사를 위와 같이 구성한 검증 데이터로 테스트')


def main3():
    st.subheader('Valiadtion')
    code = '''
with torch.no_gard():
    for val_batch in tqdm(val_loader, desc = f'Validation - Epoch{epoch +1}/{num_epochs}):
        input_ids = val_batch['input_ids'].to(device)
        attention_mask = val_batch['attention_mask'].to(device)
        labels = val_batch['labels'].to(device)
        outputs = model(input_ids, attention_mask, labels=labels)
        val_loss = outputs.loss
        total_val_loss += val_loss.item()

        #정확도 계산
             _, torch.max(outputs.logits, 1)
        total_val += labels.size(0)
        correct_val += (predicted_val == labels).sum().item()

average_val_loss = total_val_loss / len(var_loader)
val_accuracy = correct_val / total_val
'''
    yc.display_code(code)
    st.write('● Validation 결과 Loss 값 0.8796 Accuracy  값 51.55%')

def main4():
    st.subheader('Test')
    code = '''
with torch.no_gard():
    for batch in tqdm(test_loader, desc = 'Testing'):
        input_ids = batch['input_ids'].to(device)
        attention_mask = batch['attention_mask'].to(device)
        labels = batch['labels'].to(device)
             outputs = model(input_ids, attention_mask = attention_mask, labels = label)
        probabilities = torch.nn.functional.softmax(outputs.logits, dim=1)
        -, predicted = torch.max(probabilites, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()

accuracy = correct / total
'''
    yc.display_code(code)
    st.write('● Test 결과 Accuracy 값은 75.94%')
    st.markdown("<hr/>", unsafe_allow_html=True)
    st.write('● 학습 데이터셋의 가짜 뉴스 기사를 검증 데이터에 넣었을 땐 예측 성공률이 높음')
    st.write('● 네이버 뉴스 기사를 크롤링한 검증 데이터의 경우 낚시성 기사 예측률이 낮음')
# main1 함수 호출
if __name__ == "__main__":
    main1()



