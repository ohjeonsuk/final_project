import streamlit as st

def display_code(code, language='python'):
    """
    코드를 Streamlit 애플리케이션에 예쁘게 표시하는 함수.

    Parameters:
    - code (str): 표시할 코드 문자열
    - language (str): 코드 언어 (기본값: 'python')
    """
    st.code(code, language=language)