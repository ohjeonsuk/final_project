import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib.font_manager as fm
import streamlit as st

font_path = r"C:\Users\jjagj\Documents\final_project\final_project\NanumGothic.ttf"

font_prop = fm.FontProperties(fname=font_path)

plt.rcParams['font.family'] = 'NanumGothic'
plt.rcParams['axes.unicode_minus'] = False

def main():
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 10))  # 1행 2열의 서브플롯 생성

    # 첫 번째 서브플롯 그리기
    people1 = [97, 8]
    answer1 = ['있다', '없다']
    colors1 = ['#679ac9', '#bcbcbc']
    wedgeprops1 = {'width': 0.75, 'edgecolor': 'w', 'linewidth': 3}

    sns.set(style="whitegrid", palette="pastel")

    ax1.pie(people1, labels=answer1, autopct='%.1f%%', startangle=90,
            counterclock=False, colors=colors1, wedgeprops=wedgeprops1)
    
    # 첫 번째 서브플롯에 폰트 설정
    ax1.set_title('가짜뉴스를 접해본 경험', fontproperties=font_prop, fontsize=18)

    # 두 번째 서브플롯 그리기
    people2 = [90, 15]
    answer2 = ['있다', '없다']
    colors2 = ['#679ac9', '#bcbcbc']
    wedgeprops2 = {'width': 0.75, 'edgecolor': 'w', 'linewidth': 3}

    sns.set(style="whitegrid", palette="pastel")

    ax2.pie(people2, labels=answer2, autopct='%.1f%%', startangle=90,
            counterclock=False, colors=colors2, wedgeprops=wedgeprops2)
    
    # 두 번째 서브플롯에 폰트 설정
    ax2.set_title('가짜뉴스를 통해 거짓정보를 습득한 경험', fontproperties=font_prop,fontsize=18)
    plt.subplots_adjust(wspace=0.1)
    st.pyplot(fig)